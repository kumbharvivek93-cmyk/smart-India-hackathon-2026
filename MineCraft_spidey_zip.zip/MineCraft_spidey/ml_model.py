"""
ml_model.py
Single entry point the Flask app calls for risk prediction: predict_risk().

- If a trained model exists at models/risk_model.pkl, it's used.
- Otherwise falls back to a transparent rule-based scorer, so the dashboard
  is fully functional BEFORE you have a trained model.

This is intentional: swap in your trained model by running train_model.py -
nothing else in the app needs to change.
"""

import os
import joblib
import numpy as np
from feature_engineering import RAW_FEATURE_NAMES, raw_features_to_vector

# Points at the actual trained model (XGBRegressor, verified from
# Untitled.ipynb) rather than the models/risk_model.pkl placeholder path.
MODEL_PATH = os.path.join(os.path.dirname(__file__), "Minecraft_model.pkl")

RISK_LEVELS = [
    (0, 29, "LOW"),
    (30, 59, "MEDIUM"),
    (60, 79, "HIGH"),
    (80, 100, "CRITICAL"),
]


def _score_to_status(score):
    for low, high, label in RISK_LEVELS:
        if low <= score <= high:
            return label
    return "CRITICAL" if score > 100 else "LOW"


def _rule_based_score(reading):
    """
    Transparent, explainable placeholder scorer used ONLY if the trained
    model can't be loaded/fails - weighted sum of raw sensor values, capped
    at 100. Not derived from the trained model; just a safety net so the
    dashboard/API never silently produce a fake ML prediction.
    """
    weights = {
        "tilt_x_deg": 4.0,        # points per degree
        "tilt_y_deg": 4.0,
        "vibration_rms_g": 300.0,  # vibration is in small g units, needs bigger weight
        "gyro_x_dps": 1.0,
        "gyro_y_dps": 1.0,
        "gyro_z_dps": 1.0,
        "displacement_mm": 2.0,
        "crack_width_mm": 5.0,
    }

    score = 0.0
    for key, weight in weights.items():
        value = reading.get(key) or 0
        score += abs(value) * weight

    return float(min(max(score, 0), 100))


def _load_trained_model():
    if os.path.exists(MODEL_PATH):
        try:
            return joblib.load(MODEL_PATH)
        except Exception as e:
            print(f"[ml_model] Failed to load trained model, falling back to rules: {e}")
            return None
    return None


_trained_model = _load_trained_model()


def reload_model():
    """Call this after training a new model without restarting the Flask server."""
    global _trained_model
    _trained_model = _load_trained_model()


def predict_risk(reading):
    """
    reading: dict-like sensor reading (raw ESP32 payload or a DB row) that
    contains at least the fields in feature_engineering.RAW_FEATURE_NAMES.

    Returns: (risk_score: float 0-100, risk_status: str, model_used: str)
    """
    global _trained_model

    if _trained_model is not None:
        vector = np.array(raw_features_to_vector(reading)).reshape(1, -1)
        try:
            # Works for classifiers with predict_proba (e.g. RandomForest)
            if hasattr(_trained_model, "predict_proba"):
                proba = _trained_model.predict_proba(vector)[0]
                # assumes class ordering was fit with risk classes 0-3 (LOW..CRITICAL)
                # or binary anomaly (0=normal,1=anomaly) - handle both
                if len(proba) == 2:
                    score = float(proba[1] * 100)
                else:
                    score = float(np.dot(proba, [15, 45, 70, 90]))  # weighted by class midpoints
            elif hasattr(_trained_model, "decision_function"):
                # e.g. IsolationForest - lower/negative = more anomalous
                raw = _trained_model.decision_function(vector)[0]
                score = float(np.clip((0.5 - raw) * 100, 0, 100))
            else:
                score = float(np.clip(_trained_model.predict(vector)[0], 0, 100))

            return score, _score_to_status(score), "trained_model"
        except Exception as e:
            print(f"[ml_model] Trained model inference failed, using rule-based fallback: {e}")

    score = _rule_based_score(reading)
    return score, _score_to_status(score), "rule_based_fallback"
