# Mine Subsidence Monitoring System

Flask admin dashboard that receives live readings from ESP32 + MPU6050
sensor nodes, computes a risk score/status per node via a pluggable ML
model, and displays it on an auto-refreshing dashboard.

## Setup

```bash
cd mine_subsidence_app
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run the app

```bash
python app.py
```

Visit http://127.0.0.1:5000 — log in with `admin` / `admin123`.

## Test it without real hardware

In a second terminal, with `app.py` still running:

```bash
python simulate_sensor.py
```

This POSTs fake readings for 3 nodes every few seconds. `node_03` is
scripted to slowly drift (rising tilt/vibration/displacement) so you can
watch its status escalate LOW -> MEDIUM -> HIGH -> CRITICAL on the
dashboard in real time, and see it show up on the Alerts page.

## Train a model

Works with zero real data to start (synthetic, clearly labeled as such):

```bash
python train_model.py --mode synthetic --model random_forest
# or
python train_model.py --mode synthetic --model isolation_forest
```

This saves `models/risk_model.pkl`. Restart `app.py` (or call
`ml_model.reload_model()`) and the dashboard will start using it instead
of the rule-based fallback — nothing else changes, since `app.py` always
calls the same `predict_risk()` function.

Once you've logged enough real sensor data via actual ESP32 nodes, switch
to `--mode real` — see the comments in `train_model.py` for how to wire up
labeling.

## How a reading flows through the system

```
ESP32 (MPU6050) --> POST /api/sensor-data --> database.py (store raw reading)
                                            --> feature_engineering.py (rolling window -> features)
                                            --> ml_model.py predict_risk() (rule-based OR trained model)
                                            --> database.py (store prediction)
                                            --> alert if risk_score >= 60
                                            --> dashboard polls /api/nodes every 5s
```

## Project structure

```
mine_subsidence_app/
├── app.py                  # Flask routes, login, sensor ingestion API
├── database.py              # SQLite: nodes, sensor_readings, risk_predictions, alerts
├── feature_engineering.py   # Single source of truth for model features
├── ml_model.py               # predict_risk() - trained model or rule-based fallback
├── train_model.py            # Trains RandomForest / IsolationForest, saves to models/
├── simulate_sensor.py        # Sends fake sensor data for testing
├── requirements.txt
├── models/
│   └── risk_model.pkl        # created after you run train_model.py
├── data/
│   └── subsidence.db          # created on first run
├── static/
│   ├── css/style.css
│   └── js/dashboard.js
└── templates/
    ├── base.html
    ├── login.html
    ├── dashboard.html
    ├── node_detail.html
    └── alerts.html
```

## ESP32 payload format

POST to `/api/sensor-data` with JSON like:

```json
{
  "node_id": "node_01",
  "name": "Shaft A - Sensor 1",
  "location": "Level -120m, Shaft A",
  "accel_x_g": -0.050,
  "accel_y_g": 0.011,
  "accel_z_g": 0.997,
  "gyro_x_dps": 7.05,
  "gyro_y_dps": -0.05,
  "gyro_z_dps": -0.21,
  "tilt_x_deg": 0.62,
  "tilt_y_deg": 2.87,
  "vibration_rms_g": 0.00499,
  "displacement_mm": 0,
  "crack_width_mm": 0
}
```

`node_id` is required; everything else is optional per-request but needed
for meaningful risk scoring.

## Risk levels

| Score   | Status   |
|---------|----------|
| 0-29    | LOW      |
| 30-59   | MEDIUM   |
| 60-79   | HIGH     |
| 80-100  | CRITICAL |

Alerts fire automatically at HIGH (score >= 60).
