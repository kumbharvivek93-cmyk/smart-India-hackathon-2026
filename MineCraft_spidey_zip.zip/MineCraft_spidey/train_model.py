"""
train_model.py
Trains the risk model and saves it to models/risk_model.pkl.

Two modes:
  1. SYNTHETIC (default) - generates labeled synthetic data so you have a
     working model immediately, clearly separated from real sensor data.
  2. REAL - pulls actual logged readings from the DB via
     database.export_readings_for_training() once you've collected enough
     real data and labeled it (you'll need to add a 'label' column /
     mapping - see bottom of this file for guidance).

Run:
    python train_model.py --mode synthetic --model isolation_forest
    python train_model.py --mode synthetic --model random_forest
"""

import argparse
import os
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib

from feature_engineering import FEATURE_NAMES

MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")
MODEL_PATH = os.path.join(MODEL_DIR, "risk_model.pkl")


def generate_synthetic_data(n_samples=2000, random_state=42):
    """
    Generates clearly-labeled SYNTHETIC training data.
    Simulates two regimes:
      - 'normal' operation: small tilt, low/steady vibration (machinery hum)
      - 'subsidence-like' events: growing tilt, tilt rate, irregular vibration

    NOTE: This is placeholder data to get the pipeline working end-to-end.
    Replace with real labeled sensor data as it becomes available - see
    the REAL mode instructions at the bottom of this file.
    """
    rng = np.random.default_rng(random_state)
    n_normal = int(n_samples * 0.8)
    n_event = n_samples - n_normal

    # --- Normal class (label 0) ---
    normal = pd.DataFrame({
        "tilt_x": rng.normal(0.5, 0.3, n_normal).clip(0),
        "tilt_y": rng.normal(0.5, 0.3, n_normal).clip(0),
        "tilt_x_rate": rng.normal(0, 0.02, n_normal),
        "tilt_y_rate": rng.normal(0, 0.02, n_normal),
        "vib_rms_mean": rng.normal(0.005, 0.002, n_normal).clip(0),
        "vib_rms_std": rng.normal(0.001, 0.0005, n_normal).clip(0),
        "gyro_mag_mean": rng.normal(1.0, 0.5, n_normal).clip(0),
        "accel_z_mean": rng.normal(1.0, 0.01, n_normal),
        "accel_z_std": rng.normal(0.005, 0.002, n_normal).clip(0),
        "displacement_mm": rng.normal(0, 0.1, n_normal).clip(0),
        "crack_width_mm": rng.normal(0, 0.05, n_normal).clip(0),
    })
    normal["label"] = 0

    # --- Subsidence-like event class (label 1) ---
    event = pd.DataFrame({
        "tilt_x": rng.normal(4.0, 2.0, n_event).clip(0),
        "tilt_y": rng.normal(4.0, 2.0, n_event).clip(0),
        "tilt_x_rate": rng.normal(0.3, 0.15, n_event).clip(0),
        "tilt_y_rate": rng.normal(0.3, 0.15, n_event).clip(0),
        "vib_rms_mean": rng.normal(0.02, 0.01, n_event).clip(0),
        "vib_rms_std": rng.normal(0.01, 0.005, n_event).clip(0),
        "gyro_mag_mean": rng.normal(5.0, 2.0, n_event).clip(0),
        "accel_z_mean": rng.normal(0.95, 0.05, n_event),
        "accel_z_std": rng.normal(0.02, 0.01, n_event).clip(0),
        "displacement_mm": rng.normal(5.0, 3.0, n_event).clip(0),
        "crack_width_mm": rng.normal(1.0, 0.5, n_event).clip(0),
    })
    event["label"] = 1

    df = pd.concat([normal, event], ignore_index=True).sample(frac=1, random_state=random_state)
    return df


def train_random_forest(df):
    X = df[FEATURE_NAMES]
    y = df["label"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, random_state=42, class_weight="balanced"
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("\n=== Classification Report (Random Forest) ===")
    print(classification_report(y_test, y_pred, target_names=["normal", "subsidence-like"]))

    print("=== Feature Importances ===")
    for name, importance in sorted(zip(FEATURE_NAMES, clf.feature_importances_), key=lambda x: -x[1]):
        print(f"  {name:20s} {importance:.3f}")

    return clf


def train_isolation_forest(df):
    # Isolation Forest is unsupervised - train only on 'normal' data so it
    # learns what normal looks like, then flags deviations as anomalies.
    X_normal = df[df["label"] == 0][FEATURE_NAMES]

    clf = IsolationForest(
        n_estimators=200, contamination=0.1, random_state=42
    )
    clf.fit(X_normal)

    # quick sanity check against the held-out event set
    X_test = df[FEATURE_NAMES]
    y_test = df["label"]
    preds = clf.predict(X_test)  # -1 = anomaly, 1 = normal
    preds_binary = (preds == -1).astype(int)

    print("\n=== Classification Report (Isolation Forest, unsupervised) ===")
    print(classification_report(y_test, preds_binary, target_names=["normal", "subsidence-like"]))

    return clf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["synthetic", "real"], default="synthetic")
    parser.add_argument("--model", choices=["random_forest", "isolation_forest"], default="random_forest")
    parser.add_argument("--samples", type=int, default=2000)
    args = parser.parse_args()

    os.makedirs(MODEL_DIR, exist_ok=True)

    if args.mode == "synthetic":
        print(f"Generating {args.samples} synthetic samples...")
        df = generate_synthetic_data(n_samples=args.samples)
    else:
        # --- REAL DATA MODE ---
        # 1. Pull logged readings from the DB:
        #      from database import export_readings_for_training
        #      raw_rows = export_readings_for_training()
        # 2. Group into rolling windows per node and run them through
        #    feature_engineering.compute_features() to get feature dicts.
        # 3. Add a 'label' column - since subsidence events are rare and slow,
        #    you'll likely hand-label windows (0=normal, 1=event) based on
        #    field observations, or start with Isolation Forest (unsupervised)
        #    so you don't need labels at all yet.
        raise NotImplementedError(
            "Real-data training requires labeled windows - see comments in "
            "train_model.py main() for the steps to wire this up once you "
            "have enough logged data."
        )

    if args.model == "random_forest":
        model = train_random_forest(df)
    else:
        model = train_isolation_forest(df)

    joblib.dump(model, MODEL_PATH)
    print(f"\nModel saved to {MODEL_PATH}")
    print("Restart the Flask app, or call ml_model.reload_model(), to use it.")


if __name__ == "__main__":
    main()
