"""
app.py
Mine Subsidence Monitoring System - Flask web app.

Routes:
    GET  /login              - admin login page
    POST /login               - handle login
    GET  /logout              - clear session
    GET  /                    - dashboard (list of nodes with live risk score/status)
    GET  /node/<node_id>      - detail view for one node (recent readings/history)
    POST /api/sensor-data     - ESP32 nodes POST readings here
    GET  /api/nodes           - JSON list of nodes + latest risk (for polling/JS refresh)
    GET  /alerts               - recent alerts list
"""

from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from functools import wraps
import os

import database as db
from ml_model import predict_risk

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-in-production")

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

ALERT_THRESHOLD_SCORE = 60  # HIGH and above triggers an alert


# ---------- Auth ----------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------- Dashboard ----------

@app.route("/")
@login_required
def dashboard():
    nodes = db.get_all_nodes_with_latest()
    return render_template("dashboard.html", nodes=nodes)


@app.route("/node/<node_id>")
@login_required
def node_detail(node_id):
    readings = db.get_recent_readings(node_id, limit=100)
    nodes = db.get_all_nodes_with_latest()
    node = next((n for n in nodes if n["node_id"] == node_id), None)
    return render_template("node_detail.html", node=node, readings=readings, node_id=node_id)


@app.route("/alerts")
@login_required
def alerts_page():
    alerts = db.get_recent_alerts(limit=50)
    return render_template("alerts.html", alerts=alerts)


# ---------- JSON API (for dashboard auto-refresh) ----------

@app.route("/api/nodes", methods=["GET"])
@login_required
def api_nodes():
    return jsonify(db.get_all_nodes_with_latest())


# ---------- Sensor ingestion (called by ESP32 nodes) ----------

@app.route("/api/sensor-data", methods=["POST"])
def receive_sensor_data():
    payload = request.get_json(silent=True)
    if not payload:
        return jsonify({"status": "error", "message": "No JSON data received"}), 400

    node_id = payload.get("node_id")
    if not node_id:
        return jsonify({"status": "error", "message": "node_id is required"}), 400

    # 1. Register/update node
    db.upsert_node(node_id, name=payload.get("name"), location=payload.get("location"))

    # 2. Store the raw reading
    reading_id = db.insert_reading(node_id, payload)

    # 3. Predict risk directly from this raw reading (the trained model,
    #    Minecraft_model.pkl, was fit on single-row raw sensor values -
    #    see feature_engineering.RAW_FEATURE_NAMES - no windowing needed)
    risk_score, risk_status, model_used = predict_risk(payload)
    db.insert_prediction(node_id, reading_id, risk_score, risk_status, model_used)

    # 4. Raise an alert if risk is high enough
    if risk_score >= ALERT_THRESHOLD_SCORE:
        db.insert_alert(
            node_id, risk_score, risk_status,
            f"Risk score {risk_score:.1f} ({risk_status}) on node {node_id}"
        )

    return jsonify({
        "status": "success",
        "node_id": node_id,
        "risk_score": round(risk_score, 2),
        "risk_status": risk_status,
        "model_used": model_used
    })


if __name__ == "__main__":
    db.init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
