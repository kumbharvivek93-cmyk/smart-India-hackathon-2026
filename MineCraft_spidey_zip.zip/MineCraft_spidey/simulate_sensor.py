"""
simulate_sensor.py
Sends fake sensor readings to the running Flask app - useful for testing
the dashboard end-to-end before your ESP32 nodes are sending real data.

Run this WHILE app.py is running in another terminal:
    python simulate_sensor.py
"""

import requests
import random
import time

SERVER_URL = "http://127.0.0.1:5000/api/sensor-data"

NODES = [
    {"node_id": "node_01", "name": "Shaft A - Sensor 1", "location": "Level -120m, Shaft A"},
    {"node_id": "node_02", "name": "Shaft B - Sensor 1", "location": "Level -85m, Shaft B"},
    {"node_id": "node_03", "name": "Tunnel C - Sensor 2", "location": "Level -200m, Tunnel C"},
]


def generate_reading(node, drift_step=0):
    """Normal baseline noise, with node_03 slowly drifting to simulate a developing event."""
    drift = drift_step * 0.15 if node["node_id"] == "node_03" else 0

    return {
        "node_id": node["node_id"],
        "name": node["name"],
        "location": node["location"],
        "accel_x_g": round(random.uniform(-0.06, 0.06), 4),
        "accel_y_g": round(random.uniform(-0.06, 0.06), 4),
        "accel_z_g": round(1.0 - drift * 0.01 + random.uniform(-0.01, 0.01), 4),
        "gyro_x_dps": round(random.uniform(-1, 1) + drift * 0.3, 3),
        "gyro_y_dps": round(random.uniform(-1, 1), 3),
        "gyro_z_dps": round(random.uniform(-1, 1), 3),
        "tilt_x_deg": round(0.5 + drift + random.uniform(-0.2, 0.2), 3),
        "tilt_y_deg": round(0.5 + drift + random.uniform(-0.2, 0.2), 3),
        "vibration_rms_g": round(0.005 + drift * 0.002 + random.uniform(0, 0.002), 5),
        "displacement_mm": round(drift * 0.8, 2),
        "crack_width_mm": round(drift * 0.15, 3),
    }


def main():
    print(f"Simulating {len(NODES)} nodes -> POST {SERVER_URL}")
    print("Press Ctrl+C to stop.\n")
    drift_step = 0
    try:
        while True:
            for node in NODES:
                reading = generate_reading(node, drift_step)
                try:
                    resp = requests.post(SERVER_URL, json=reading, timeout=5)
                    result = resp.json()
                    print(f"{node['node_id']}: risk={result.get('risk_score')} "
                          f"status={result.get('risk_status')} model={result.get('model_used')}")
                except requests.exceptions.ConnectionError:
                    print("Could not connect - is app.py running on port 5000?")
            drift_step += 1
            time.sleep(3)
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
