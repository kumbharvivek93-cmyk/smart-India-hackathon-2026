"""
database.py
SQLite helper for the Mine Subsidence Monitoring System.

Tables:
    nodes             - one row per physical sensor node (ESP32 + MPU6050)
    sensor_readings    - raw + derived readings coming from /api/sensor-data
    risk_predictions   - ML output (risk_score, status) per reading
    alerts             - triggered when risk crosses a threshold
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "subsidence.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS nodes (
            node_id TEXT PRIMARY KEY,
            name TEXT,
            location TEXT,
            status TEXT DEFAULT 'offline',
            last_seen TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS sensor_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id TEXT,
            timestamp TEXT,
            accel_x_g REAL,
            accel_y_g REAL,
            accel_z_g REAL,
            gyro_x_dps REAL,
            gyro_y_dps REAL,
            gyro_z_dps REAL,
            tilt_x_deg REAL,
            tilt_y_deg REAL,
            vibration_rms_g REAL,
            displacement_mm REAL,
            crack_width_mm REAL,
            FOREIGN KEY (node_id) REFERENCES nodes (node_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS risk_predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id TEXT,
            reading_id INTEGER,
            timestamp TEXT,
            risk_score REAL,
            risk_status TEXT,
            model_used TEXT,
            FOREIGN KEY (node_id) REFERENCES nodes (node_id),
            FOREIGN KEY (reading_id) REFERENCES sensor_readings (id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id TEXT,
            timestamp TEXT,
            risk_score REAL,
            risk_status TEXT,
            message TEXT,
            acknowledged INTEGER DEFAULT 0,
            FOREIGN KEY (node_id) REFERENCES nodes (node_id)
        )
    """)

    conn.commit()
    conn.close()


def upsert_node(node_id, name=None, location=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT node_id FROM nodes WHERE node_id = ?", (node_id,))
    exists = cur.fetchone()
    now = datetime.now().isoformat()

    if exists:
        cur.execute(
            "UPDATE nodes SET status = 'online', last_seen = ? WHERE node_id = ?",
            (now, node_id)
        )
    else:
        cur.execute(
            "INSERT INTO nodes (node_id, name, location, status, last_seen) VALUES (?, ?, ?, 'online', ?)",
            (node_id, name or node_id, location or "Unassigned", now)
        )
    conn.commit()
    conn.close()


def insert_reading(node_id, data):
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.now().isoformat()
    cur.execute("""
        INSERT INTO sensor_readings (
            node_id, timestamp, accel_x_g, accel_y_g, accel_z_g,
            gyro_x_dps, gyro_y_dps, gyro_z_dps,
            tilt_x_deg, tilt_y_deg, vibration_rms_g,
            displacement_mm, crack_width_mm
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        node_id, now,
        data.get("accel_x_g"), data.get("accel_y_g"), data.get("accel_z_g"),
        data.get("gyro_x_dps"), data.get("gyro_y_dps"), data.get("gyro_z_dps"),
        data.get("tilt_x_deg"), data.get("tilt_y_deg"), data.get("vibration_rms_g"),
        data.get("displacement_mm", 0), data.get("crack_width_mm", 0)
    ))
    reading_id = cur.lastrowid
    conn.commit()
    conn.close()
    return reading_id


def insert_prediction(node_id, reading_id, risk_score, risk_status, model_used):
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.now().isoformat()
    cur.execute("""
        INSERT INTO risk_predictions (node_id, reading_id, timestamp, risk_score, risk_status, model_used)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (node_id, reading_id, now, risk_score, risk_status, model_used))
    conn.commit()
    conn.close()


def insert_alert(node_id, risk_score, risk_status, message):
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.now().isoformat()
    cur.execute("""
        INSERT INTO alerts (node_id, timestamp, risk_score, risk_status, message)
        VALUES (?, ?, ?, ?, ?)
    """, (node_id, now, risk_score, risk_status, message))
    conn.commit()
    conn.close()


def get_all_nodes_with_latest():
    """Returns each node with its latest reading + latest risk prediction (for dashboard)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM nodes")
    nodes = [dict(row) for row in cur.fetchall()]

    for node in nodes:
        cur.execute("""
            SELECT * FROM sensor_readings WHERE node_id = ?
            ORDER BY id DESC LIMIT 1
        """, (node["node_id"],))
        reading = cur.fetchone()
        node["latest_reading"] = dict(reading) if reading else None

        cur.execute("""
            SELECT * FROM risk_predictions WHERE node_id = ?
            ORDER BY id DESC LIMIT 1
        """, (node["node_id"],))
        prediction = cur.fetchone()
        node["latest_prediction"] = dict(prediction) if prediction else None

    conn.close()
    return nodes


def get_recent_readings(node_id, limit=50):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM sensor_readings WHERE node_id = ?
        ORDER BY id DESC LIMIT ?
    """, (node_id, limit))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return list(reversed(rows))  # chronological order


def get_recent_alerts(limit=20):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def export_readings_for_training():
    """Pulls all readings joined with predictions - useful as a starting CSV for labeling/training."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM sensor_readings ORDER BY id ASC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows
