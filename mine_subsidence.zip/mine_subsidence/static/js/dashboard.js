// dashboard.js
// Currently no interactivity is required — node data is rendered
// server-side by Flask/Jinja from the `nodes` list in app.py.
//
// This file is a placeholder for future client-side behavior once
// live sensor data is available, for example:
//   - Polling GET /api/nodes every few seconds to refresh scores
//     without a full page reload.
//   - Animating the score bar fill on load.
//   - Showing a toast/notification when a node crosses into
//     HIGH or CRITICAL status.

document.addEventListener("DOMContentLoaded", () => {
    console.log("Mine Subsidence Monitoring dashboard loaded.");
});
