"""
app.py
------
Mine Subsidence Monitoring System — Flask prototype.

Single admin login + a dashboard that displays risk score / risk status
for a set of sensor nodes. No ML model is wired in yet — node data comes
from the `nodes` list below and can be swapped for real predictions
later (see the "CONNECT YOUR ML MODEL HERE" section).
"""

from functools import wraps
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash

from config import Config
from ml_model import predict_risk

app = Flask(__name__)
app.config.from_object(Config)


# ---------------------------------------------------------------------------
# Risk status logic — shared by the dashboard now and by the ML model later.
# ---------------------------------------------------------------------------
def get_risk_status(score):
    """
    Convert a numeric risk score (0-100) into a risk status label.

        0-29    -> LOW
        30-59   -> MEDIUM
        60-79   -> HIGH
        80-100  -> CRITICAL
    """
    if score < 30:
        return "LOW"
    elif score < 60:
        return "MEDIUM"
    elif score < 80:
        return "HIGH"
    else:
        return "CRITICAL"


# ---------------------------------------------------------------------------
# Node / sensor data.
#
# CONNECT YOUR ML MODEL HERE:
# Right now `risk_score` values are hard-coded. Later, replace the
# hard-coded numbers with a call to predict_risk(sensor_data) from
# ml_model.py, e.g.:
#
#     score = predict_risk(sensor_data_for_node_01)
#     nodes = [{"id": "NODE-01", "risk_score": score, "status": get_risk_status(score)}, ...]
#
# The dashboard template only cares about each node's "id", "risk_score",
# and "status" keys, so this swap won't require any HTML/CSS changes.
# ---------------------------------------------------------------------------
def get_nodes():
    """
    Returns the current list of sensor nodes with risk score and status.

    This is intentionally a function (not a flat module-level list) so
    that later you can swap the body for real-time predictions without
    changing how routes call it.
    """
    raw_nodes = [
        {"id": "NODE-01", "risk_score": 32},
        {"id": "NODE-02", "risk_score": 76},
    ]

    nodes = []
    for node in raw_nodes:
        # Example of the future data shape each node's prediction would
        # eventually be based on (currently unused dummy values):
        # sensor_data = {
        #     "node_id": node["id"],
        #     "tilt_x": 1.82,
        #     "tilt_y": 2.14,
        #     "vibration": 0.42,
        #     "displacement": 12.4,
        #     "crack_width": 1.2,
        # }
        # node["risk_score"] = predict_risk(sensor_data)

        node["status"] = get_risk_status(node["risk_score"])
        nodes.append(node)

    return nodes


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def login_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped_view


@app.after_request
def add_no_cache_headers(response):
    """
    Prevent the browser from serving a cached copy of protected pages
    (like /dashboard) after logout, e.g. via the back button.
    """
    if request.path == "/dashboard":
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))

    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        valid_username = username == app.config["ADMIN_USERNAME"]
        valid_password = check_password_hash(app.config["ADMIN_PASSWORD_HASH"], password)

        if valid_username and valid_password:
            session.clear()
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))
        else:
            error = "Invalid username or password"

    return render_template("login.html", error=error)


@app.route("/dashboard")
@login_required
def dashboard():
    nodes = get_nodes()
    last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return render_template(
        "dashboard.html",
        nodes=nodes,
        admin_name="Admin",
        last_updated=last_updated,
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Future API placeholder (not implemented yet).
#
# When ESP32 sensors are wired up, this is where they will POST readings:
#
#     @app.route("/api/sensor-data", methods=["POST"])
#     def receive_sensor_data():
#         data = request.get_json()
#         score = predict_risk(data)
#         status = get_risk_status(score)
#         # store / update the relevant node, then return a JSON response
#         return {"node_id": data.get("node_id"), "risk_score": score, "status": status}
#
# Left commented out intentionally per current scope.
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    app.run(debug=True)
