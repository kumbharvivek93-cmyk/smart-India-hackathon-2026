"""
ml_model.py
-----------
Placeholder module for the future AI risk-prediction model.

Nothing here is trained or loaded yet. This file exists purely so the
rest of the application (dashboard, routes, future ESP32 API) can be
wired up against a stable function signature today, and later you can
drop your real model in without touching any other file.

HOW TO CONNECT YOUR REAL MODEL LATER
-------------------------------------
1. Load your trained model once, near the top of this file, e.g.:

       import joblib
       model = joblib.load("model.pkl")

2. Replace the body of predict_risk() below with something like:

       def predict_risk(sensor_data):
           features = [[
               sensor_data["tilt_x"],
               sensor_data["tilt_y"],
               sensor_data["vibration"],
               sensor_data["displacement"],
               sensor_data["crack_width"],
           ]]
           prediction = model.predict(features)[0]
           return float(prediction)

3. Nothing in app.py needs to change — it already calls
   predict_risk(sensor_data) and feeds the result into
   get_risk_status() to determine LOW/MEDIUM/HIGH/CRITICAL.
"""


def predict_risk(sensor_data):
    """
    Placeholder for future ML model.

    Args:
        sensor_data (dict): Expected shape, once real sensors are wired up:
            {
                "node_id": "NODE-01",
                "tilt_x": 1.82,
                "tilt_y": 2.14,
                "vibration": 0.42,
                "displacement": 12.4,
                "crack_width": 1.2
            }

    Returns:
        float: A risk score between 0 and 100.

    Replace this function with the actual ML prediction logic later,
    e.g. `return model.predict(...)`.
    """
    return 50
