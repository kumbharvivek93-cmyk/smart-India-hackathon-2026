import os

class Config:
    """
    Central configuration for the Flask app.

    SECRET_KEY is read from an environment variable when available.
    A fallback value is provided ONLY for local development so the
    prototype runs out-of-the-box. Set a real FLASK_SECRET_KEY env
    var before deploying anywhere beyond your own machine.
    """
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "dev-only-change-this-secret-key")

    # Fixed prototype admin credentials.
    # There is only one admin account, so no user database is used.
    ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")

    # Werkzeug password hash of "admin123", generated with
    # generate_password_hash("admin123"). Kept as a hash (not plaintext)
    # so the raw password is never stored or compared directly.
    # This hash corresponds to the password "admin123". Generated with:
    #   from werkzeug.security import generate_password_hash
    #   generate_password_hash("admin123")
    ADMIN_PASSWORD_HASH = os.environ.get(
        "ADMIN_PASSWORD_HASH",
        "scrypt:32768:8:1$j0WtgbkGXjAbgiU5$312d8b2c420a8cd3d63ed992fa289c76c850c4bf11177223c9508cf34e53ce643dae5aa18ac93ce6c417de6b47ed97a756b0c009cc3c2c0c63cf60b109414eff",
    )

    # Session behavior
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60  # 1 hour, in seconds
