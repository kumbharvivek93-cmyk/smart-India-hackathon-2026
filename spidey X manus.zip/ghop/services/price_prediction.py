from __future__ import annotations

from statistics import mean


DISCLAIMER = "AI-based estimated price. Actual market prices may vary."


def summarize_price_trend(prices: list[float]) -> str:
    if len(prices) < 2:
        return "stable"
    baseline = prices[0] or 0
    current = prices[-1] or 0
    if baseline == 0:
        delta_pct = 0
    else:
        delta_pct = ((current - baseline) / baseline) * 100
    if delta_pct > 3:
        return "increasing"
    if delta_pct < -3:
        return "decreasing"
    return "stable"


def build_market_advice(
    current_price: float,
    predicted_price: float,
    trend: str,
    arrival_quantity: float | None,
    storage_available: bool,
) -> dict:
    arrival_quantity = arrival_quantity or 0
    price_gap = predicted_price - current_price
    recommendation = "SELL NOW"
    reason = "The current market is at least as strong as the short-term estimate."

    if predicted_price > current_price and trend == "increasing" and storage_available:
        recommendation = "WAIT"
        reason = "Predicted price is higher than the current price and storage is available."
    elif predicted_price > current_price and arrival_quantity > 0 and arrival_quantity < 120:
        recommendation = "WAIT"
        reason = "Lower arrivals and a higher forecast suggest prices may improve."
    elif predicted_price < current_price:
        recommendation = "SELL NOW"
        reason = "Predicted price is lower than the current price."
    elif not storage_available and predicted_price > current_price:
        reason = "Prices may improve, but no matching storage option is available."

    return {
        "recommendation": recommendation,
        "reason": reason,
        "price_gap": round(price_gap, 2),
        "disclaimer": DISCLAIMER,
    }


def _fallback_prediction(rows: list, prediction_days: int) -> dict:
    recent = rows[-min(len(rows), 7) :]
    prices = [row.modal_price for row in recent if row.modal_price is not None]
    current_price = prices[-1]
    predicted_price = round(mean(prices), 2)
    trend = summarize_price_trend(prices)
    confidence = 0.32 if len(rows) < 10 else 0.46
    return {
        "current_price": current_price,
        "predicted_price": predicted_price,
        "trend": trend,
        "confidence": round(confidence, 2),
        "model": "moving_average_fallback",
        "prediction_days": prediction_days,
        "used_fallback": True,
        "disclaimer": DISCLAIMER,
    }


def predict_market_price(rows: list, prediction_days: int = 7) -> dict:
    usable_rows = [row for row in rows if row.modal_price is not None]
    if not usable_rows:
        raise ValueError("No market data available.")
    if len(usable_rows) < 5:
        return _fallback_prediction(usable_rows, prediction_days)

    try:
        import pandas as pd
        from sklearn.ensemble import RandomForestRegressor
    except ImportError:
        return _fallback_prediction(usable_rows, prediction_days)

    data = pd.DataFrame(
        {
            "date": [row.date for row in usable_rows],
            "modal_price": [row.modal_price for row in usable_rows],
            "arrival_quantity": [row.arrival_quantity or 0 for row in usable_rows],
        }
    ).sort_values("date")
    data["previous_price"] = data["modal_price"].shift(1)
    data["month"] = data["date"].apply(lambda value: value.month)
    data["day"] = data["date"].apply(lambda value: value.day)
    data["dayofweek"] = data["date"].apply(lambda value: value.weekday())
    data = data.dropna()

    if len(data) < 4:
        return _fallback_prediction(usable_rows, prediction_days)

    features = data[["previous_price", "arrival_quantity", "month", "day", "dayofweek"]]
    target = data["modal_price"]

    model = RandomForestRegressor(n_estimators=150, random_state=42)
    model.fit(features, target)

    latest = data.iloc[-1]
    current_price = float(latest["modal_price"])
    feature_row = pd.DataFrame(
        [
            {
                "previous_price": latest["modal_price"],
                "arrival_quantity": latest["arrival_quantity"],
                "month": latest["month"],
                "day": latest["day"],
                "dayofweek": latest["dayofweek"],
            }
        ]
    )
    predicted_price = round(float(model.predict(feature_row)[0]), 2)
    trend = summarize_price_trend(data["modal_price"].tolist()[-10:])
    confidence = min(0.88, 0.45 + (len(data) * 0.03))
    return {
        "current_price": round(current_price, 2),
        "predicted_price": predicted_price,
        "trend": trend,
        "confidence": round(confidence, 2),
        "model": "random_forest_regressor",
        "prediction_days": prediction_days,
        "used_fallback": False,
        "disclaimer": DISCLAIMER,
    }
