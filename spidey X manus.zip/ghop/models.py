from datetime import datetime

from extensions import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), nullable=False, unique=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    farmer_profile = db.relationship("Farmer", back_populates="user", uselist=False)
    buyer_profile = db.relationship("Buyer", back_populates="user", uselist=False)
    disputes = db.relationship("Dispute", back_populates="raised_by_user")


class Farmer(db.Model):
    __tablename__ = "farmers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(15))
    village = db.Column(db.String(100))
    taluka = db.Column(db.String(100))
    district = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pincode = db.Column(db.String(10))
    farm_size = db.Column(db.Float)
    farm_size_unit = db.Column(db.String(20))
    fpo_member = db.Column(db.Boolean, default=False, nullable=False)
    fpo_name = db.Column(db.String(150))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="farmer_profile")
    crops = db.relationship("FarmerCrop", back_populates="farmer", cascade="all, delete-orphan")
    lots = db.relationship("Lot", back_populates="farmer", cascade="all, delete-orphan")
    received_offers = db.relationship("Offer", back_populates="farmer")
    transactions = db.relationship("Transaction", back_populates="farmer")
    ratings = db.relationship("Rating", back_populates="farmer")


class Buyer(db.Model):
    __tablename__ = "buyers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    company_name = db.Column(db.String(150), nullable=False)
    contact_person = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    email = db.Column(db.String(100))
    address = db.Column(db.String(255))
    village_city = db.Column(db.String(100))
    district = db.Column(db.String(100))
    state = db.Column(db.String(100))
    business_type = db.Column(db.String(100))
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    verification_date = db.Column(db.DateTime)
    rating = db.Column(db.Float, default=0.0, nullable=False)
    total_transactions = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", back_populates="buyer_profile")
    requirements = db.relationship("BuyerRequirement", back_populates="buyer", cascade="all, delete-orphan")
    offers = db.relationship("Offer", back_populates="buyer")
    transactions = db.relationship("Transaction", back_populates="buyer")
    ratings = db.relationship("Rating", back_populates="buyer")


class Crop(db.Model):
    __tablename__ = "crops"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    category = db.Column(db.String(50))
    unit = db.Column(db.String(20))
    description = db.Column(db.Text)

    farmer_crops = db.relationship("FarmerCrop", back_populates="crop")
    market_prices = db.relationship("MarketPrice", back_populates="crop")
    lots = db.relationship("Lot", back_populates="crop")
    buyer_requirements = db.relationship("BuyerRequirement", back_populates="crop")
    price_predictions = db.relationship("PricePrediction", back_populates="crop")


class FarmerCrop(db.Model):
    __tablename__ = "farmer_crops"

    id = db.Column(db.Integer, primary_key=True)
    farmer_id = db.Column(db.Integer, db.ForeignKey("farmers.id"), nullable=False)
    crop_id = db.Column(db.Integer, db.ForeignKey("crops.id"), nullable=False)
    variety = db.Column(db.String(100))
    area = db.Column(db.Float)
    area_unit = db.Column(db.String(20))
    sowing_date = db.Column(db.Date)
    expected_harvest_date = db.Column(db.Date)
    expected_quantity = db.Column(db.Float)

    farmer = db.relationship("Farmer", back_populates="crops")
    crop = db.relationship("Crop", back_populates="farmer_crops")


class MarketPrice(db.Model):
    __tablename__ = "market_prices"

    id = db.Column(db.Integer, primary_key=True)
    crop_id = db.Column(db.Integer, db.ForeignKey("crops.id"), nullable=False)
    market_name = db.Column(db.String(150), nullable=False)
    district = db.Column(db.String(100))
    state = db.Column(db.String(100))
    price_min = db.Column(db.Float)
    price_max = db.Column(db.Float)
    modal_price = db.Column(db.Float)
    arrival_quantity = db.Column(db.Float)
    arrival_unit = db.Column(db.String(20))
    date = db.Column(db.Date, nullable=False)
    source = db.Column(db.String(100))

    crop = db.relationship("Crop", back_populates="market_prices")


class Lot(db.Model):
    __tablename__ = "lots"

    id = db.Column(db.Integer, primary_key=True)
    farmer_id = db.Column(db.Integer, db.ForeignKey("farmers.id"), nullable=False)
    crop_id = db.Column(db.Integer, db.ForeignKey("crops.id"), nullable=False)
    lot_number = db.Column(db.String(50), unique=True, nullable=False)
    variety = db.Column(db.String(100))
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    harvest_date = db.Column(db.Date)
    quality_grade = db.Column(db.String(20))
    quality_score = db.Column(db.Float)
    moisture = db.Column(db.Float)
    foreign_matter = db.Column(db.Float)
    damage_percentage = db.Column(db.Float)
    expected_price = db.Column(db.Float)
    location = db.Column(db.String(255))
    description = db.Column(db.Text)
    image = db.Column(db.String(255))
    status = db.Column(db.String(30), default="available", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    farmer = db.relationship("Farmer", back_populates="lots")
    crop = db.relationship("Crop", back_populates="lots")
    offers = db.relationship("Offer", back_populates="lot")
    transactions = db.relationship("Transaction", back_populates="lot")


class BuyerRequirement(db.Model):
    __tablename__ = "buyer_requirements"

    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey("buyers.id"), nullable=False)
    crop_id = db.Column(db.Integer, db.ForeignKey("crops.id"), nullable=False)
    required_quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    min_quality_grade = db.Column(db.String(20))
    max_price = db.Column(db.Float)
    delivery_location = db.Column(db.String(255))
    required_by = db.Column(db.Date)
    description = db.Column(db.Text)
    status = db.Column(db.String(30), default="open", nullable=False)

    buyer = db.relationship("Buyer", back_populates="requirements")
    crop = db.relationship("Crop", back_populates="buyer_requirements")


class Offer(db.Model):
    __tablename__ = "offers"

    id = db.Column(db.Integer, primary_key=True)
    lot_id = db.Column(db.Integer, db.ForeignKey("lots.id"), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey("buyers.id"), nullable=False)
    farmer_id = db.Column(db.Integer, db.ForeignKey("farmers.id"), nullable=False)
    offered_price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    message = db.Column(db.Text)
    status = db.Column(db.String(30), default="pending", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime)

    lot = db.relationship("Lot", back_populates="offers")
    buyer = db.relationship("Buyer", back_populates="offers")
    farmer = db.relationship("Farmer", back_populates="received_offers")
    transaction = db.relationship("Transaction", back_populates="offer", uselist=False)


class Transaction(db.Model):
    __tablename__ = "transactions"

    id = db.Column(db.Integer, primary_key=True)
    transaction_number = db.Column(db.String(50), unique=True, nullable=False)
    offer_id = db.Column(db.Integer, db.ForeignKey("offers.id"), nullable=False)
    farmer_id = db.Column(db.Integer, db.ForeignKey("farmers.id"), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey("buyers.id"), nullable=False)
    lot_id = db.Column(db.Integer, db.ForeignKey("lots.id"), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    price_per_unit = db.Column(db.Float, nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    delivery_status = db.Column(db.String(30), default="pending", nullable=False)
    transaction_status = db.Column(db.String(30), default="pending", nullable=False)

    offer = db.relationship("Offer", back_populates="transaction")
    farmer = db.relationship("Farmer", back_populates="transactions")
    buyer = db.relationship("Buyer", back_populates="transactions")
    lot = db.relationship("Lot", back_populates="transactions")
    transport_requests = db.relationship("TransportRequest", back_populates="transaction")
    payments = db.relationship("Payment", back_populates="transaction")
    disputes = db.relationship("Dispute", back_populates="transaction")
    ratings = db.relationship("Rating", back_populates="transaction")


class TransportProvider(db.Model):
    __tablename__ = "transport_providers"

    id = db.Column(db.Integer, primary_key=True)
    provider_name = db.Column(db.String(150), nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    vehicle_type = db.Column(db.String(50), nullable=False)
    vehicle_number = db.Column(db.String(30), unique=True, nullable=False)
    capacity = db.Column(db.Float, nullable=False)
    cost_per_km = db.Column(db.Float, nullable=False)
    rating = db.Column(db.Float, default=0.0, nullable=False)
    is_available = db.Column(db.Boolean, default=True, nullable=False)

    transport_requests = db.relationship("TransportRequest", back_populates="provider")


class TransportRequest(db.Model):
    __tablename__ = "transport_requests"

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey("transactions.id"), nullable=False)
    provider_id = db.Column(db.Integer, db.ForeignKey("transport_providers.id"), nullable=False)
    pickup_location = db.Column(db.String(255), nullable=False)
    delivery_location = db.Column(db.String(255), nullable=False)
    distance_km = db.Column(db.Float)
    estimated_cost = db.Column(db.Float)
    request_date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    status = db.Column(db.String(30), default="requested", nullable=False)

    transaction = db.relationship("Transaction", back_populates="transport_requests")
    provider = db.relationship("TransportProvider", back_populates="transport_requests")


class StorageFacility(db.Model):
    __tablename__ = "storage_facilities"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(255), nullable=False)
    district = db.Column(db.String(100), nullable=False)
    storage_type = db.Column(db.String(50), nullable=False)
    total_capacity = db.Column(db.Float, nullable=False)
    available_capacity = db.Column(db.Float, nullable=False)
    cost_per_quintal_day = db.Column(db.Float, nullable=False)
    phone = db.Column(db.String(15))
    rating = db.Column(db.Float, default=0.0, nullable=False)


class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey("transactions.id"), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50))
    transaction_reference = db.Column(db.String(100), unique=True)
    payment_date = db.Column(db.DateTime)
    status = db.Column(db.String(30), default="pending", nullable=False)
    notes = db.Column(db.Text)

    transaction = db.relationship("Transaction", back_populates="payments")


class Dispute(db.Model):
    __tablename__ = "disputes"

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey("transactions.id"), nullable=False)
    raised_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(30), default="open", nullable=False)
    resolution = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    resolved_at = db.Column(db.DateTime)

    transaction = db.relationship("Transaction", back_populates="disputes")
    raised_by_user = db.relationship("User", back_populates="disputes")


class Rating(db.Model):
    __tablename__ = "ratings"

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey("transactions.id"), nullable=False)
    farmer_id = db.Column(db.Integer, db.ForeignKey("farmers.id"), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey("buyers.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    review = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    transaction = db.relationship("Transaction", back_populates="ratings")
    farmer = db.relationship("Farmer", back_populates="ratings")
    buyer = db.relationship("Buyer", back_populates="ratings")


class PricePrediction(db.Model):
    __tablename__ = "price_predictions"

    id = db.Column(db.Integer, primary_key=True)
    crop_id = db.Column(db.Integer, db.ForeignKey("crops.id"), nullable=False)
    market_name = db.Column(db.String(150), nullable=False)
    current_price = db.Column(db.Float, nullable=False)
    predicted_price = db.Column(db.Float, nullable=False)
    prediction_days = db.Column(db.Integer, nullable=False)
    trend = db.Column(db.String(30))
    recommendation = db.Column(db.String(255))
    confidence = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    crop = db.relationship("Crop", back_populates="price_predictions")
