// Polls /api/nodes every 5s and re-renders the node grid + summary counts
// without a full page reload. Kept deliberately simple (no framework),
// per project preference for plain HTML/CSS/JS.

const REFRESH_MS = 5000;

function statusClass(status) {
  return (status || "offline").toLowerCase();
}

function renderNodeCard(node) {
  const pred = node.latest_prediction;
  const reading = node.latest_reading;
  const status = pred ? pred.risk_status : "offline";
  const cls = statusClass(status);

  let readoutHtml = "";
  if (reading) {
    readoutHtml = `
      <div class="readout-grid">
        <div>tilt_x <span class="v">${reading.tilt_x_deg.toFixed(2)}°</span></div>
        <div>tilt_y <span class="v">${reading.tilt_y_deg.toFixed(2)}°</span></div>
        <div>vib_rms <span class="v">${reading.vibration_rms_g.toFixed(4)}g</span></div>
        <div>displ <span class="v">${reading.displacement_mm}mm</span></div>
      </div>`;
  }

  const scoreHtml = pred
    ? `${Math.round(pred.risk_score)}<span class="unit">/100</span>`
    : `&mdash;<span class="unit">no data</span>`;

  return `
    <a class="node-card status-${cls}" href="/node/${node.node_id}">
      <div class="row-top">
        <div>
          <div class="node-name">${node.name}</div>
          <div class="node-location">${node.location}</div>
        </div>
        <span class="status-pill status-${cls}">${status}</span>
      </div>
      <div class="risk-score">${scoreHtml}</div>
      ${readoutHtml}
      <span class="view-link">View history</span>
    </a>
  `;
}

async function refreshDashboard() {
  try {
    const res = await fetch("/api/nodes");
    if (!res.ok) return;
    const nodes = await res.json();

    const grid = document.getElementById("node-grid");
    if (grid) {
      grid.innerHTML = nodes.map(renderNodeCard).join("");
    }

    const counts = { LOW: 0, MEDIUM: 0, HIGH: 0, CRITICAL: 0 };
    nodes.forEach((n) => {
      if (n.latest_prediction && counts.hasOwnProperty(n.latest_prediction.risk_status)) {
        counts[n.latest_prediction.risk_status]++;
      }
    });
    const cells = document.querySelectorAll(".summary-cell .num");
    if (cells.length === 4) {
      cells[0].textContent = counts.LOW;
      cells[1].textContent = counts.MEDIUM;
      cells[2].textContent = counts.HIGH;
      cells[3].textContent = counts.CRITICAL;
    }

    const updated = document.getElementById("last-updated");
    if (updated) {
      const now = new Date();
      updated.textContent = `updated ${now.toLocaleTimeString()}`;
    }
  } catch (e) {
    console.error("Dashboard refresh failed:", e);
  }
}

setInterval(refreshDashboard, REFRESH_MS);
