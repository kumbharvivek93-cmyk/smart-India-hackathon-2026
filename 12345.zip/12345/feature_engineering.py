"""
feature_engineering.py
Converts a window of raw sensor_readings rows into the feature vector
the ML model expects. Keep this file as the SINGLE SOURCE OF TRUTH for
features - both train_model.py and ml_model.py import from here so
training and live inference never drift apart.
"""

import numpy as np

# Order matters - this defines the exact feature vector the model sees.
FEATURE_NAMES = [
    "tilt_x",
    "tilt_y",
    "tilt_x_rate",
    "tilt_y_rate",
    "vib_rms_mean",
    "vib_rms_std",
    "gyro_mag_mean",
    "accel_z_mean",
    "accel_z_std",
    "displacement_mm",
    "crack_width_mm",
]


def compute_features(readings):
    """
    readings: list of dicts (chronological order), each with keys matching
    sensor_readings columns (accel_x_g, gyro_x_dps, tilt_x_deg, ...).
    Needs at least 2 readings for rate/std features; falls back gracefully
    to 0 if fewer are available (e.g. very first reading from a node).

    Returns: dict {feature_name: value}
    """
    if not readings:
        return {name: 0.0 for name in FEATURE_NAMES}

    tilt_x = np.array([r["tilt_x_deg"] for r in readings], dtype=float)
    tilt_y = np.array([r["tilt_y_deg"] for r in readings], dtype=float)
    vib = np.array([r["vibration_rms_g"] for r in readings], dtype=float)
    accel_z = np.array([r["accel_z_g"] for r in readings], dtype=float)
    gyro_x = np.array([r["gyro_x_dps"] for r in readings], dtype=float)
    gyro_y = np.array([r["gyro_y_dps"] for r in readings], dtype=float)
    gyro_z = np.array([r["gyro_z_dps"] for r in readings], dtype=float)
    displacement = readings[-1].get("displacement_mm", 0) or 0
    crack_width = readings[-1].get("crack_width_mm", 0) or 0

    gyro_mag = np.sqrt(gyro_x**2 + gyro_y**2 + gyro_z**2)

    # rate of change (degrees per reading-interval) - simple first difference
    if len(readings) >= 2:
        tilt_x_rate = float(tilt_x[-1] - tilt_x[0]) / max(len(tilt_x) - 1, 1)
        tilt_y_rate = float(tilt_y[-1] - tilt_y[0]) / max(len(tilt_y) - 1, 1)
    else:
        tilt_x_rate = 0.0
        tilt_y_rate = 0.0

    features = {
        "tilt_x": float(tilt_x[-1]),
        "tilt_y": float(tilt_y[-1]),
        "tilt_x_rate": tilt_x_rate,
        "tilt_y_rate": tilt_y_rate,
        "vib_rms_mean": float(np.mean(vib)),
        "vib_rms_std": float(np.std(vib)),
        "gyro_mag_mean": float(np.mean(gyro_mag)),
        "accel_z_mean": float(np.mean(accel_z)),
        "accel_z_std": float(np.std(accel_z)),
        "displacement_mm": float(displacement),
        "crack_width_mm": float(crack_width),
    }
    return features


def features_to_vector(features_dict):
    """Converts a feature dict into an ordered list matching FEATURE_NAMES - what the model expects."""
    return [features_dict[name] for name in FEATURE_NAMES]
